To use:
Install node packages
Run with nodemon
There are 2 test accounts each listing 2 items:
Email:Test@gmail.com Password:1234
Email:test2@gmail.com Passwrod:1234
